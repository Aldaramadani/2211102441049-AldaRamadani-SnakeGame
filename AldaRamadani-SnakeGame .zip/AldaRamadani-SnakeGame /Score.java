import greenfoot.*; 

public class Score extends Actor
{
    public void setScore(int a)
    {
        setImage(new GreenfootImage(""+a,32, Color.BLACK,null));
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}