import greenfoot.*;  

public class Makanan extends Actor
{
    public void addedToWorld(World Latar)
    {
        
    }
    
    private void setGambar(int d)
    {
        
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
